﻿namespace Models
{
    public enum Location
    {
        Metro,
        NonMetro
    }
}
