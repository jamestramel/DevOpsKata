﻿namespace TaxCalculators
{
    using Models;

    public interface ITaxCalculator
    {
        uint Calculate(
            bool        IsRented,
            Location    location,
            uint        AnnualBasicSalary,
            uint        MonthlyRent,
            uint        AnnualHouseRentAllowance);
    }
}
