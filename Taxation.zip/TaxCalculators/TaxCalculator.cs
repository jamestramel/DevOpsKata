﻿#region Namespaces
using System;
using Models;
#endregion

namespace TaxCalculators
{

    public class TaxCalculator
    {

        public uint CalculateExemptionForRent(
            Employee        employee,
            ITaxCalculator  calculator)
        {
            var taxExemption = calculator.Calculate(
                employee.Property.IsRented,
                employee.Property.Location,
                employee.AnnualBasicSalary,
                employee.Property.MonthlyRent,
                employee.AnnualHouseRentAllowance);

            return taxExemption;
        }

    }

}
