﻿#region Namespaces
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DAL;
using Models;
#endregion

namespace TaxCalculators
{

    public class TaxRecord
    {

        private IDAL _repository;

        public TaxRecord(IDAL repository)
        {
            _repository = repository;
        }

        public bool EmployeeHRADeductionEligible(Employee employee)
        {
            uint val = _repository.HRA(employee);

            if (val > 0)
                return true;
            else
                return false;
        }

    }

}
