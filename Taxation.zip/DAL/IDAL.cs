﻿#region Namespaces
using Models;
#endregion

namespace DAL
{

    public interface IDAL
    {

        uint HRA(Employee e);

    }

}
