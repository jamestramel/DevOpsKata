﻿
namespace John.SocialClub.Data.Enum
{
    public enum Occupation
    {
        Unknown = 0,
        Doctor,
        Engineer,
        Professor
    }
}
