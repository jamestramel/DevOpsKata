﻿
namespace John.SocialClub.Data.Enum
{
    public enum MaritalStatus
    {
        Unknown = 0,
        Married,
        Single
    }
}
