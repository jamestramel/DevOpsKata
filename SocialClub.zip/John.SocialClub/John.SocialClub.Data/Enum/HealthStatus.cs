﻿
namespace John.SocialClub.Data.Enum
{
    public enum HealthStatus
    {
        Unknown = 0,
        Excellent,
        Good,
        Average,
        Poor
    }
}
